package com.example.internet.katalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternetKatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
