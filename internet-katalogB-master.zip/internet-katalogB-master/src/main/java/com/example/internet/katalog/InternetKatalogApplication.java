package com.example.internet.katalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternetKatalogApplication {

	public static void main(String[] args) {

		SpringApplication.run(InternetKatalogApplication.class, args);
	}

}
